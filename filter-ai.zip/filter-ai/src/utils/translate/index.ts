import { __ } from '@wordpress/i18n';

export const t = (text: string) => {
  return __(text, 'filter-ai');
};
