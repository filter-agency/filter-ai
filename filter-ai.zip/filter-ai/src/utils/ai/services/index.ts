export * from './generateText';
