export const verticalDots =
  'data:image/svg+xml;charset=utf-8,%3Csvg%20width%3D%2224%22%20height%3D%2225%22%20viewBox%3D%220%200%2024%2025%22%20fill%3D%22none%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%0A%3Cpath%20d%3D%22M13%2019.5H11V17.5H13V19.5ZM13%2013.5H11V11.5H13V13.5ZM13%207.5H11V5.5H13V7.5Z%22%20fill%3D%22%231E1E1E%22%2F%3E%0A%3C%2Fsvg%3E%0A';
