const GenerateImgTab = () => {
  return (
    <div style={{ padding: '1rem' }}>
      <h1>Generate AI Image</h1>
      <p>This content is rendered from React (.tsx).</p>
    </div>
  );
};

export default GenerateImgTab;
